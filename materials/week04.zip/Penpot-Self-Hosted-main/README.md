# Penpot Self-Hosted Setup

This repository contains the Docker Compose configuration for running a self-hosted Penpot instance.

## Prerequisites

- Docker and Docker Compose installed on your system
- Basic knowledge of Docker commands

## Quick Start

### 1. Start Penpot


To start the Penpot instance, run:

> **Note:** Make sure Docker is running before executing the command.

```bash
docker compose -p penpot -f docker-compose.yml up -d
```

This will:
- Download the latest Penpot images
- Start all required services (frontend, backend, database, etc.)
- Make Penpot available at `http://localhost:9001`

### 2. Access Penpot

Once all containers are running, open your browser and navigate to:
```
http://localhost:9001
```

### 3. Create Your First User

Since email verification is disabled by default, you can create a user account directly through the web interface.

### 4. Learn How to Use Penpot

Once you have access to Penpot, you can learn how to use all the features and capabilities through these resources:

- **[Official User Guide](https://help.penpot.app/user-guide/)** - Comprehensive documentation
- **[Penpot Tutorial Playlist](https://www.youtube.com/playlist?list=PLrNBWyhqEoKEzgkk38MLeYNiNgDpKvVTv)** - Video tutorials
- **[Additional Penpot Tutorials](https://www.youtube.com/playlist?list=PLqazFFzUAPc7g3Yw_0O3LqookKRnnfdZj)** - More video tutorials
- **[Penpot YouTube Channel](https://www.youtube.com/@Penpot/playlists)** - Additional video content and playlists

---

## Management Commands

> **Note:** The following sections are for advanced users who need to manage and maintain their Penpot instance.

### Stop Penpot

To stop the running instance:

```bash
docker compose -p penpot -f docker-compose.yml down
```

### Restart Penpot

To restart the services:

```bash
docker compose -p penpot -f docker-compose.yml restart
```

### View Logs

To view logs from all services:

```bash
docker compose -p penpot -f docker-compose.yml logs
```

To view logs from a specific service:

```bash
docker compose -p penpot -f docker-compose.yml logs penpot-backend
```

### Check Status

To see which containers are running:

```bash
docker compose -p penpot -f docker-compose.yml ps
```

## Administrative Tasks

### Create User via CLI

If you need to create a user account via command line:

```bash
docker exec -ti penpot-penpot-backend-1 python3 manage.py create-profile
```

Or with additional options:

```bash
docker exec -ti penpot-penpot-backend-1 python3 manage.py create-profile --skip-tutorial --skip-walkthrough
```

**Note:** The exact container name may vary. Check with `docker ps` to see the correct container name.

## Updates

### Update to Latest Version

To update to the latest Penpot version:

```bash
docker compose -f docker-compose.yml pull
docker compose -p penpot -f docker-compose.yml up -d
```

### Update to Specific Version

To update to a specific version:

```bash
PENPOT_VERSION=2.4.3 docker compose -p penpot -f docker-compose.yml up -d
```

## Configuration

The current configuration includes:
- **Email verification**: Disabled (for easy setup)
- **SMTP**: Enabled with mailcatcher for testing
- **Secure cookies**: Disabled (for localhost usage)
- **Registration**: Enabled

### Important Notes

- **For production use**: Enable email verification and secure cookies
- **For internet access**: Configure proper HTTPS and remove `disable-secure-session-cookies` flag
- **Email setup**: Configure real SMTP settings instead of using mailcatcher

## Services

The setup includes the following services:
- **penpot-frontend**: Web interface (port 9001)
- **penpot-backend**: API and business logic
- **penpot-exporter**: Export functionality
- **penpot-postgres**: Database
- **penpot-valkey**: Cache and websockets
- **penpot-mailcatch**: Email testing (port 1080)

## Troubleshooting

### Container Issues

If containers fail to start, check logs:

```bash
docker compose -p penpot -f docker-compose.yml logs [service-name]
```

### Database Issues

If the database seems corrupted, you can reset it by removing the volume:

```bash
docker compose -p penpot -f docker-compose.yml down -v
docker compose -p penpot -f docker-compose.yml up -d
```

**Warning:** This will delete all your data!

### Port Conflicts

If port 9001 is already in use, modify the port mapping in `docker-compose.yml`:

```yaml
ports:
  - 9002:8080  # Change 9001 to 9002
```

## Backup

To backup your Penpot data:

```bash
# Backup database
docker run --rm -v penpot_penpot_postgres_v15:/data -v $(pwd):/backup alpine tar czf /backup/postgres-backup.tar.gz -C /data .

# Backup assets
docker run --rm -v penpot_penpot_assets:/data -v $(pwd):/backup alpine tar czf /backup/assets-backup.tar.gz -C /data .
```


---

**Happy designing with Penpot!**
